const pg = require("pg");
const { readFileSync } = require("fs");
const tunnel = require("tunnel-ssh");
const dbServer = {
  user: "whvteacx_admin",
  database: "whvteacx_hollagram",
  password: "zGu_xths_sc7",
  port: 5432,
  host: "127.0.0.1",
};
// define connection config for the ssh tunnel

const pg_pool = new pg.Pool(dbServer);
const pg_client = new pg.Client(dbServer);

/* var config = {
  username: "whvteacx",
  password: "5DxAYRLq!Lzf",
  host: "66.29.132.14",
  port: 21098,
  dstHost: "127.0.0.1",
  dstPort: 5432,
  localHost: "127.0.0.1",
  localPort: 5432,
  keepAlive: true,
  privateKey: readFileSync("C:/Users/oyina/Downloads/id_postgresql"),
  passphrase: "5DxAYRLq!Lzf",
};

var server = tunnel(config, function (error, server) {
  if (error) {
    console.log("SSH connection error: " + error);
  } */
pg_client
  .connect()
  .then(() => {
    console.log("Db connected");
  })
  .catch((err) => console.error("connection error", err.stack));
/* }); */

//module.exports = { pg_pool, server };
module.exports = { pg_pool };
